import pymongo
import random
from pprint import pprint

def connect():
    user = "adra"
    password = "mongodbadra"
    database = "don"
    return pymongo.MongoClient(f"mongodb+srv://{user}:{password}@adra.gjziu.mongodb.net/{database}?retryWrites=true&w=majority")

client = connect()
db = client.don.form

list_nom = ['Bokalli', 'Bonneau', 'Chaigneau', 'Cloatre', 'Furiga', 'Guillen', 'Hergoualc\'h', 'Ibanni', 'Karfaoui', 'Le Berre', 'Le Goff', 'Le Joncour', 'Le Moal', 'Maintier', 'Moulard', 'Petron', 'Rioual', 'Sabia', 'Verpoest' ]

list_prenom = ['Liam', 'Noah', 'Oliver', 'William', 'Elijah', 'James', 'Benjamin', 'Lucas', 'Mason', 'Ethan', 'Olivia', 'Emma',
         'Ava', 'Sophia', 'Isabella', 'Charlotte', 'Amelia', 'Mia', 'Harper']

random.shuffle(list_nom)
random.shuffle(list_prenom)

somme_list=[]
#for i in range (20):
    #somme_list.append(random.randrange(0,2000,10))

#for nom, prenom, somme in zip(list_nom, list_prenom, somme_list):
    #db.insert_one({'nom': nom, 'prenom' : prenom, 'don' : somme})

