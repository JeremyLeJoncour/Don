import pymongo
from flask import Flask, render_template, request, url_for, flash, redirect
from werkzeug.exceptions import abort
    
def connect():
    user = "adra"
    password = "mongodbadra"
    database = "don"
    return pymongo.MongoClient(f"mongodb+srv://{user}:{password}@adra.gjziu.mongodb.net/{database}?retryWrites=true&w=majority")

client = connect()
db = client.don.form

app = Flask(__name__)
app.config['SECRET_KEY'] = 'adrammalech'
app.jinja_env.filters['zip'] = zip

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/formulaire', methods=('POST','GET'))
def formulaire():
    if request.method == 'POST':
        nom = request.form['inputFirstName']
        prenom = request.form['inputLastName']
        mail = request.form['inputEmail4']
        adresse = request.form['inputAddress']
        ville = request.form['inputCity']
        somme = int(request.form['inputNumber'])
        db.insert_one({'nom': nom, 'prenom' : prenom, 'email' : mail, 'adresse' : adresse, 'ville' : ville, 'don' : somme})
        return redirect(url_for('index'))
    return render_template('formulaire.html')

@app.route('/donnateurs', methods = ['GET'])
def donnateurs():
    donnateurs = list(db.find({}, {"nom":1,"prenom":1, "don":1}).sort("don",-1))
    somme = list(db.aggregate([{'$group': {'_id':'null','don':{'$sum': '$don'}}}]))
    img = ["static/don1.jpg", "static/don2.jpg","static/don3.jpg"]
    return render_template('donnateurs.html', donnateurs=donnateurs, somme=somme, img=img)